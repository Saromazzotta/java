package com.saro.zookeeper;

public class Bat extends Mammal {
	private int energyLevel = 300;

	
	// Constructor 
	public Bat() {
		super();
	}
	
	// METHODS
	public void fly() {
		System.out.println("Zsshshshshhh...The bat is flying." + " " + "Energy Level: " + this.energyLevel);
		this.energyLevel -= 50;
	}
	
	public void eatHumans() {
		System.out.println("Not looking good...There goes 1 human." + " " + "Energy Level: " + this.energyLevel);
		this.energyLevel += 25;
	}
	
	public void attackTown() {
		System.out.println("SDJCCrcrcrcrcrrkkkksshshhcjc...Burning sounds can be heard form the distance." + " " + "Energy Level: " + this.energyLevel);
		this.energyLevel -= 100;
	}
	
}
