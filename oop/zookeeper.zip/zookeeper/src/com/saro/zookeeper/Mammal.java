package com.saro.zookeeper;

public class Mammal {
	protected int energyLevels = 100;
	
	// CONSTRUCTOR
	public Mammal() {
		
	}
	
	
	// METHODS
	public int displayEnergy() {
		System.out.println(this.energyLevels);
		return this.energyLevels;
	}


	public int getEnergyLevels() {
		return energyLevels;
	}


	public void setEnergyLevels(int energyLevels) {
		this.energyLevels = energyLevels;
	}
	
	
	
	
}