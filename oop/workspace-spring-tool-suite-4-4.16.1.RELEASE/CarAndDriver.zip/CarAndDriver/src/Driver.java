
public class Driver extends Car {

	
	// constructor
	public Driver() {
		super();
	
	}


}
