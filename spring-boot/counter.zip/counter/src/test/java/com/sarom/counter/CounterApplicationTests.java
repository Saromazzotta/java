package com.sarom.counter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CounterApplicationTests {

	@Test
	void contextLoads() {
	}

}
