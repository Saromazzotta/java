package com.sarom.loginandreg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginandregApplicationTests {

	@Test
	void contextLoads() {
	}

}
