package com.sarom.hopperreceipt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HopperreceiptApplication {

	public static void main(String[] args) {
		SpringApplication.run(HopperreceiptApplication.class, args);
	}

}
